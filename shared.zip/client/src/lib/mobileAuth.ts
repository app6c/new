// Sistema de autenticação alternativo para dispositivos móveis
// que funciona com token persistente no localStorage

// Chave para armazenar o token no localStorage
const MOBILE_TOKEN_KEY = 'mobile_auth_token';
const MOBILE_USER_KEY = 'mobile_auth_user';

// Verifica se é dispositivo móvel
export function isMobileDevice(): boolean {
  if (typeof window === 'undefined') return false;
  
  const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  const isSmallScreen = window.innerWidth < 768;
  
  return mobileRegex.test(userAgent) || isSmallScreen;
}

// Verifica especificamente se é um dispositivo Apple (iOS/iPadOS)
export function isAppleDevice(): boolean {
  if (typeof window === 'undefined') return false;
  
  const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
  return /iPhone|iPad|iPod/i.test(userAgent);
}

// Verifica se é Safari ou WebView no iOS
export function isSafariMobile(): boolean {
  if (typeof window === 'undefined') return false;
  
  const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
  return /iPhone|iPad|iPod/i.test(userAgent) && 
         /Safari/i.test(userAgent) &&
         !/Chrome/i.test(userAgent);
}

// Salva o token no localStorage
export function saveAuthToken(token: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(MOBILE_TOKEN_KEY, token);
}

// Salva informações do usuário no localStorage
export function saveAuthUser(user: any): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(MOBILE_USER_KEY, JSON.stringify(user));
}

// Obtém o token do localStorage
export function getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(MOBILE_TOKEN_KEY);
}

// Obtém informações do usuário do localStorage
export function getAuthUser(): any {
  if (typeof window === 'undefined') return null;
  const userJson = localStorage.getItem(MOBILE_USER_KEY);
  if (!userJson) return null;
  
  try {
    return JSON.parse(userJson);
  } catch (e) {
    console.error('Erro ao fazer parse do usuário no localStorage:', e);
    return null;
  }
}

// Remove token e informações do usuário no logout
export function clearAuthData(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(MOBILE_TOKEN_KEY);
  localStorage.removeItem(MOBILE_USER_KEY);
}

// API Request com token para dispositivos móveis
export async function mobileAuthRequest(
  method: string, 
  url: string, 
  data?: any
): Promise<any> {
  const token = getAuthToken();
  const isMobile = isMobileDevice();
  
  // Adicionar timestamp e parâmetro aleatório para prevenir cache
  const timestamp = Date.now();
  const randomParam = Math.random();
  const urlWithParams = url.includes('?') 
    ? `${url}&_t=${timestamp}&_=${randomParam}` 
    : `${url}?_t=${timestamp}&_=${randomParam}`;
  
  // Configurar headers
  const headers: Record<string, string> = {
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  };
  
  // Adicionar Content-Type se tiver dados
  if (data) {
    headers['Content-Type'] = 'application/json';
  }
  
  // Adicionar token de autenticação se disponível
  if (token) {
    headers['X-Mobile-Auth-Token'] = token;
  }
  
  console.log(`📱 Mobile Auth Request: ${method} ${urlWithParams} (Com token: ${!!token})`);
  
  try {
    // Fazer requisição com 3 tentativas
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const response = await fetch(urlWithParams, {
          method,
          headers,
          body: data ? JSON.stringify(data) : undefined,
          credentials: 'include',
          cache: 'no-store',
          mode: 'cors'
        });
        
        // Verificar se há token na resposta
        const newToken = response.headers.get('X-Mobile-Auth-Token');
        if (newToken) {
          saveAuthToken(newToken);
          console.log('📱 Novo token recebido e salvo');
        }
        
        if (!response.ok) {
          console.warn(`📱 Tentativa ${attempt}: Erro ${response.status} em ${url}`);
          
          // Se for erro 401 (não autorizado)
          if (response.status === 401) {
            console.log("📱 Erro de autenticação");
            
            // Se for uma requisição para /api/login, não devemos tentar novamente
            if (url.includes('/api/login')) {
              const errorText = await response.text();
              throw new Error(errorText);
            }
            
            // Limpar dados de autenticação para forçar novo login
            clearAuthData();
            
            // Se não for a última tentativa, tentar novamente
            if (attempt < 3) {
              await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
              continue;
            }
          }
          
          // Para outros erros
          const errorText = await response.text();
          throw new Error(`${response.status}: ${errorText || response.statusText}`);
        }
        
        // Se a resposta for bem-sucedida, retornar os dados
        const text = await response.text();
        if (!text) return null;
        
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error("📱 Erro ao parsear JSON:", e);
          return text;
        }
      } catch (fetchError) {
        console.error(`📱 Tentativa ${attempt} falhou:`, fetchError);
        
        // Se não for a última tentativa, tentar novamente
        if (attempt < 3) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          continue;
        }
        
        throw fetchError;
      }
    }
  } catch (error) {
    console.error("📱 Todas as tentativas falharam:", error);
    throw error;
  }
  
  return null;
}