import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { 
  isMobileDevice, 
  mobileAuthRequest, 
  getAuthToken,
  isAppleDevice,
  isSafariMobile
} from "./mobileAuth";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Função para limpar caches específicos ou todos
export function clearCaches(queryKeys?: string[] | string) {
  if (!queryKeys) {
    // Limpar todos os caches
    queryClient.clear();
    return;
  }
  
  if (typeof queryKeys === 'string') {
    queryClient.invalidateQueries({ queryKey: [queryKeys] });
  } else {
    queryKeys.forEach(key => {
      queryClient.invalidateQueries({ queryKey: [key] });
    });
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  options?: RequestInit
): Promise<any> {
  // Apple Safari Mobile SEMPRE usa token, pois cookies não funcionam direito
  if (isSafariMobile() || (isMobileDevice() && getAuthToken())) {
    console.log(`📱 ${isSafariMobile() ? 'Safari iOS' : 'Mobile com token'} - usando mobileAuthRequest: ${method} ${url}`);
    
    // Para dispositivos Apple, sempre incluir o token no cabeçalho se disponível
    try {
      return await mobileAuthRequest(method, url, data);
    } catch (error) {
      console.error(`📱 Erro em mobileAuthRequest: ${error}`);
      
      // Apenas para Safari no iOS, não tente o método padrão para evitar problemas de cookie
      if (isSafariMobile()) {
        throw error;
      }
      // Para outros dispositivos, continue com a implementação normal se houver erro
    }
  }
  
  // Adicionar headers de no-cache para garantir dados atualizados
  const headers: Record<string, string> = {
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "Pragma": "no-cache",
    "Expires": "0"
  };
  
  // Adicionar Content-Type se tiver dados
  if (data) {
    headers["Content-Type"] = "application/json";
  }
  
  // Verificar se é uma requisição de dispositivo móvel
  const isMobile = isMobileDevice();
  
  // Adicionar timestamp na URL para evitar cache em dispositivos móveis
  let urlWithTimestamp = url;
  if (isMobile) {
    urlWithTimestamp = url.includes('?') 
      ? `${url}&_t=${Date.now()}&_=${Math.random()}` 
      : `${url}?_t=${Date.now()}&_=${Math.random()}`;
  }
  
  console.log(`Enviando requisição ${method} para ${urlWithTimestamp} (Mobile: ${isMobile})`, 
    data ? { withData: true, dataKeys: Object.keys(data) } : { withData: false });
  
  const res = await fetch(urlWithTimestamp, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include", // Incluir cookies para autenticação
    cache: "no-store",
    ...options
  });

  console.log(`Resposta para ${method} ${url}: status=${res.status}`);
  
  // Se a resposta for 401, tratamos de forma especial
  if (res.status === 401) {
    if (url === '/api/me') {
      console.log('Usuário não autenticado em /api/me');
      return null;
    } else if (url === '/api/user-analysis-requests' || url === '/api/all-analysis-requests') {
      // Para as rotas específicas de análises (tanto usuário comum quanto admin), 
      // apenas lançamos o erro sem fazer redirecionamento automático
      console.warn(`Erro de autenticação em ${url} - tratamento especial para mobile`);
      const errorText = await res.text();
      throw new Error(`${res.status}: ${errorText || res.statusText}`);
    } else {
      console.error(`Erro de autenticação em ${url}`);
      const errorText = await res.text();
      
      // Se não estamos em /api/logout (que naturalmente retorna 401 após logout), 
      // redirecionamos para a página de landing
      if (url !== '/api/logout' && method.toUpperCase() !== 'POST') {
        console.log('Redirecionando para página de landing devido a erro de autenticação');
        // Timeout para garantir que o redirecionamento não interrompa a execução da função atual
        setTimeout(() => {
          window.location.href = '/landing/';
        }, 100);
      }
      
      throw new Error(`${res.status}: ${errorText || res.statusText}`);
    }
  } else if (!res.ok) {
    // Para outros erros, lançamos uma exceção
    const errorText = await res.text();
    console.error(`Erro na requisição ${method} ${url}: ${res.status} - ${errorText}`);
    throw new Error(`${res.status}: ${errorText || res.statusText}`);
  }
  
  // Para GET ou métodos que retornam dados, retornar o JSON
  const contentType = res.headers.get('content-type');
  if (method.toUpperCase() === 'GET' || 
     (contentType && contentType.includes('application/json'))) {
    // Verifica se há conteúdo antes de tentar fazer parse JSON
    const text = await res.text();
    if (text) {
      try {
        return JSON.parse(text);
      } catch (e) {
        console.error(`Erro ao fazer parse do JSON em ${url}:`, e);
        return text; // Retornar o texto bruto se não for JSON válido
      }
    }
    return null; // Retornar null se não houver conteúdo
  }
  
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Safari iOS ou dispositivos móveis com token usam a abordagem de token
    if (isSafariMobile() || (isMobileDevice() && getAuthToken())) {
      console.log(`📱 ${isSafariMobile() ? 'Safari iOS' : 'Mobile com token'} - usando mobileAuthRequest para ${queryKey[0]}`);
      try {
        return await mobileAuthRequest("GET", queryKey[0] as string);
      } catch (error) {
        console.error(`📱 Erro em mobileAuthRequest (getQueryFn): ${error}`);
        
        // Se for Safari iOS e não conseguir com token, não tente a forma normal
        if (isSafariMobile()) {
          if (unauthorizedBehavior === "returnNull") {
            return null;
          }
          throw error;
        }
        
        // Para outros dispositivos, retornar null para 401 ou continuar com abordagem normal
        if (unauthorizedBehavior === "returnNull" && (error as Error).message.includes("401")) {
          return null;
        }
        // Para outros erros em outros dispositivos, tentamos o fluxo normal abaixo
      }
    }
    
    // Verificar se é uma requisição de dispositivo móvel para adicionar timestamp
    const isMobile = isMobileDevice();
    
    // Modificar a URL com timestamp para evitar cache em dispositivos móveis
    let url = queryKey[0] as string;
    if (isMobile) {
      url = url.includes('?') 
        ? `${url}&_t=${Date.now()}&_=${Math.random()}` 
        : `${url}?_t=${Date.now()}&_=${Math.random()}`;
      console.log(`QueryClient (Mobile): Usando URL com timestamp: ${url}`);
    }
    
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
      }
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: true, // Atualiza quando o usuário volta para a janela
      refetchOnMount: true, // Atualiza quando o componente é montado
      refetchOnReconnect: true, // Atualiza quando reconecta
      staleTime: 30 * 1000, // 30 segundos antes de considerar os dados desatualizados
      retry: 3, // Tentar novamente até 3 vezes em caso de falha
      retryDelay: attempt => Math.min(1000 * Math.pow(2, attempt), 30000), // Backoff exponencial
      gcTime: 10 * 60 * 1000, // 10 minutos - remove do cache após 10 minutos de inatividade
    },
    mutations: {
      retry: 1, // Tentar novamente 1 vez em caso de falha
    },
  },
});
