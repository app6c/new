import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Função para formatar data ISO para o formato dd/mm/yyyy
export function formatDate(dateString: string): string {
  if (!dateString) return "";
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "Data inválida";
    
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    }).format(date);
  } catch (error) {
    console.error("Erro ao formatar data:", error);
    return "Data inválida";
  }
}

// Função para detectar se o dispositivo é mobile
export function isMobileDevice(): boolean {
  const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
  
  // Padrões para detectar dispositivos móveis
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  
  // Verificar se a largura da tela é compatível com mobile (< 768px)
  const isSmallScreen = window.innerWidth < 768;
  
  return mobileRegex.test(userAgent) || isSmallScreen;
}

// Função para fazer requisições API robustas em dispositivos móveis
export async function mobileApiRequest(url: string, options: RequestInit = {}): Promise<any> {
  // Configurações para evitar cache, especialmente em mobile
  const headers = {
    ...options.headers,
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "Pragma": "no-cache",
    "Expires": "0"
  };

  // Adicionar timestamp na URL para evitar cache
  const timestampedUrl = url.includes('?') 
    ? `${url}&_t=${Date.now()}` 
    : `${url}?_t=${Date.now()}`;
  
  console.log(`📱 Requisição mobile para: ${timestampedUrl}`);
  
  try {
    // Fazer requisição com 3 tentativas
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const response = await fetch(timestampedUrl, {
          ...options,
          headers,
          credentials: 'include',
          cache: 'no-store',
          mode: 'cors'
        });
        
        if (!response.ok) {
          console.warn(`📱 Tentativa ${attempt}: Erro ${response.status} em ${url}`);
          
          // Se for erro 401, retornar array vazio em vez de redirecionar
          if (response.status === 401) {
            console.log("📱 Erro de autenticação, retornando array vazio");
            return [];
          }
          
          // Se não for a última tentativa, tentar novamente
          if (attempt < 3) {
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
            continue;
          }
          
          throw new Error(`${response.status}: ${await response.text() || response.statusText}`);
        }
        
        // Se a resposta for bem-sucedida, retornar os dados
        const text = await response.text();
        if (!text) return [];
        
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error("📱 Erro ao parsear JSON:", e);
          return [];
        }
      } catch (fetchError) {
        console.error(`📱 Tentativa ${attempt} falhou:`, fetchError);
        
        // Se não for a última tentativa, tentar novamente
        if (attempt < 3) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          continue;
        }
        
        throw fetchError;
      }
    }
  } catch (error) {
    console.error("📱 Todas as tentativas falharam:", error);
    return [];
  }
  
  return [];
}
