import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import enTranslation from '../locales/en.json';
import ptTranslation from '../locales/pt.json';

// Função para obter o idioma do navegador ou usar o padrão
const getBrowserLanguage = (): string => {
  const language = navigator.language;
  if (language.startsWith('pt')) return 'pt';
  return 'en';
};

// Função para obter o idioma salvo no localStorage
const getSavedLanguage = (): string => {
  const savedLanguage = localStorage.getItem('language');
  if (savedLanguage === 'pt' || savedLanguage === 'en') {
    return savedLanguage;
  }
  return getBrowserLanguage();
};

// Inicializar i18n
i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: enTranslation
      },
      pt: {
        translation: ptTranslation
      }
    },
    lng: getSavedLanguage(),
    fallbackLng: 'en',
    debug: false, // Desativa logs detalhados para produção
    interpolation: {
      escapeValue: false, // não é necessário para o React
    },
  });

// Função para aplicar traduções a todos os componentes
export const applyTranslationsGlobally = () => {
  // Esta função força a renderização de componentes que usam o hook useTranslation
  // Isso ajuda a garantir que todas as traduções sejam aplicadas corretamente
  document.dispatchEvent(new CustomEvent('apply-translations'));
};

// Função para alterar o idioma em toda a aplicação
export const changeLanguage = (language: string): void => {
  console.log(`Alterando idioma para: ${language}`);
  
  // Salvar o idioma no localStorage para persistir entre sessões
  localStorage.setItem('language', language);
  
  // Alterar o idioma no i18n
  i18n.changeLanguage(language).then(() => {
    console.log(`Idioma alterado para: ${i18n.language}`);
    
    // Aplicar traduções globalmente (para componentes que escutam o evento)
    applyTranslationsGlobally();
    
    // Forçar recarregamento da página para garantir que todas as traduções sejam aplicadas
    sessionStorage.setItem('languageChanged', 'true');
    setTimeout(() => {
      window.location.reload();
    }, 500);
  }).catch(err => {
    console.error(`Erro ao alterar idioma para ${language}:`, err);
  });
};

export default i18n;