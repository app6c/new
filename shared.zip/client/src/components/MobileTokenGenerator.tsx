import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Key, Database, Check, X, AlertCircle, LogIn, UserCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { getAuthToken, saveAuthToken, saveAuthUser, clearAuthData } from '@/lib/mobileAuth';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';

export function MobileTokenGenerator() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  // Login direto
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  // Verificar token existente ao carregar
  useEffect(() => {
    const existingToken = getAuthToken();
    if (existingToken) {
      setToken(existingToken);
    }
  }, []);

  const generateToken = async () => {
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      // Fazer uma solicitação direta para gerar token
      const response = await fetch('/api/me?_=' + Math.random(), {
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        },
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${await response.text()}`);
      }

      const userData = await response.json();
      if (!userData) {
        throw new Error('Nenhum dado de usuário recebido');
      }

      // Gerar token local (temporário, até implementar no backend)
      // Na prática, isso força a chamada para o middleware no backend
      // que vai gerar o token e adicioná-lo ao cabeçalho da resposta
      const tokenRes = await apiRequest('GET', '/api/me');
      
      // Verificar se há token existente após a chamada
      const newToken = getAuthToken();
      if (newToken) {
        setToken(newToken);
        setSuccess(true);
        
        // Garantir que o usuário está salvo
        saveAuthUser(userData);
      } else {
        throw new Error('Token não foi gerado ou salvado');
      }
    } catch (err) {
      console.error('Erro ao gerar token:', err);
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const clearToken = () => {
    clearAuthData();
    setToken(null);
    setSuccess(false);
  };

  const testApiWithToken = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Forçar uma chamada usando o token existente
      const analysisData = await apiRequest('GET', '/api/user-analysis-requests');
      console.log('Resposta da API com token:', analysisData);
      
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao testar API com token:', err);
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  // Login direto
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Preencha o usuário e senha');
      return;
    }
    
    setLoginLoading(true);
    setError(null);
    
    try {
      // Fazer login diretamente
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password }),
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${await response.text()}`);
      }

      const userData = await response.json();
      
      // Login bem-sucedido, gerar token
      setSuccess(true);
      
      // Tentar gerar o token automaticamente
      setTimeout(() => {
        generateToken();
      }, 1000);
      
    } catch (err) {
      console.error('Erro ao fazer login:', err);
      setError((err as Error).message);
    } finally {
      setLoginLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="bg-primary text-primary-foreground">
        <CardTitle className="flex items-center">
          <Key className="h-5 w-5 mr-2" /> 
          Sistema Mobile para {token ? 'Testar API' : 'Gerar Token'}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4 space-y-4">
        {error && (
          <div className="bg-destructive/10 text-destructive p-3 rounded-md flex items-center">
            <AlertCircle className="h-4 w-4 mr-2" />
            <span className="text-sm">{error}</span>
          </div>
        )}
        
        {success && (
          <div className="bg-green-100 text-green-800 p-3 rounded-md flex items-center">
            <Check className="h-4 w-4 mr-2" />
            <span className="text-sm">{token ? 'Teste realizado com sucesso!' : 'Token gerado com sucesso!'}</span>
          </div>
        )}
        
        {!token && (
          <>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Usuário</Label>
                <Input 
                  id="username" 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Seu nome de usuário"
                  autoComplete="username"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Sua senha"
                  autoComplete="current-password"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loginLoading}
              >
                {loginLoading ? (
                  <>
                    <UserCircle className="h-4 w-4 mr-2 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  <>
                    <LogIn className="h-4 w-4 mr-2" />
                    Entrar no Sistema
                  </>
                )}
              </Button>
            </form>

            <Separator className="my-4" />
            
            <Button 
              onClick={generateToken} 
              disabled={loading} 
              className="w-full"
              variant="outline"
            >
              {loading ? (
                <>
                  <Key className="h-4 w-4 mr-2 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Key className="h-4 w-4 mr-2" />
                  Gerar Token para Mobile (Requer Login Anterior)
                </>
              )}
            </Button>
          </>
        )}
        
        {token && (
          <div className="space-y-4">
            <div className="text-sm">
              <div className="font-medium mb-1">Token atual:</div>
              <div className="bg-muted p-2 rounded-md font-mono text-xs break-all">
                {token}
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button onClick={testApiWithToken} disabled={loading} size="sm" variant="default">
                {loading ? (
                  <>
                    <Database className="h-4 w-4 mr-2 animate-pulse" />
                    Testando...
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4 mr-2" />
                    Testar API de Análises
                  </>
                )}
              </Button>
              
              <Button onClick={clearToken} size="sm" variant="destructive">
                <X className="h-4 w-4 mr-2" />
                Limpar token
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}