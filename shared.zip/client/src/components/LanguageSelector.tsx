import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { changeLanguage } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function LanguageSelector() {
  const { t, i18n } = useTranslation();
  const [currentLanguage, setCurrentLanguage] = useState(i18n.language);
  const { toast } = useToast();

  // Atualiza o estado quando o idioma muda externamente
  useEffect(() => {
    setCurrentLanguage(i18n.language);
    
    // Configurar um detector de alterações de idioma
    const handleLanguageChanged = (lng: string) => {
      console.log(`Idioma mudou para: ${lng}`);
      setCurrentLanguage(lng);
    };
    
    i18n.on('languageChanged', handleLanguageChanged);
    
    return () => {
      i18n.off('languageChanged', handleLanguageChanged);
    };
  }, [i18n]);

  const handleLanguageChange = (lang: string) => {
    console.log(`Solicitando mudança de idioma para: ${lang}`);
    
    if (lang === currentLanguage) {
      console.log('Idioma já está selecionado');
      return;
    }
    
    // Notificar o usuário antes de recarregar a página
    toast({
      title: lang === 'pt' ? 'Idioma alterado' : 'Language changed',
      description: lang === 'pt' ? 'Aplicando traduções em todas as páginas...' : 'Applying translations to all pages...',
      duration: 2000,
    });
    
    // Usar a função aprimorada de alteração de idioma
    // Esta função cuida de:
    // 1. Salvar no localStorage
    // 2. Alterar o idioma no i18n
    // 3. Disparar evento para aplicar traduções
    // 4. Recarregar a página para garantir tradução em todos os componentes
    changeLanguage(lang);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="px-3 py-1 border border-border rounded z-50 bg-opacity-80 backdrop-blur-sm"
        >
          {currentLanguage === 'pt' ? '🇧🇷 PT' : '🇺🇸 EN'}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => handleLanguageChange('pt')}>
          🇧🇷 {t('language.pt')}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleLanguageChange('en')}>
          🇺🇸 {t('language.en')}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default LanguageSelector;