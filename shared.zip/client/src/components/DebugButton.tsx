import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';
import { Bug, RefreshCw } from 'lucide-react';

export const DebugButton = ({ variant = 'outline', size = 'sm' }: { variant?: 'default' | 'outline'; size?: 'sm' | 'icon' | 'lg' | 'default' }) => {
  const { toast } = useToast();
  
  const refreshSession = async () => {
    try {
      const response = await fetch('/api/debug/refresh-session', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Sessão atualizada",
          description: `Sessão válida até ${new Date(data.expires).toLocaleString()}`,
        });
      } else {
        toast({
          title: "Falha ao atualizar sessão",
          description: "Tente fazer login novamente",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível conectar ao servidor",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="flex gap-2">
      <Button 
        variant={variant} 
        size={size}
        onClick={refreshSession}
      >
        <RefreshCw className="h-4 w-4 mr-1" />
        Refresh Sessão
      </Button>
      
      <Button 
        variant={variant} 
        size={size} 
        asChild
      >
        <Link href="/debug">
          <Bug className="h-4 w-4 mr-1" />
          Debug
        </Link>
      </Button>
    </div>
  );
};