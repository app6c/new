
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  isMobileDevice, 
  saveAuthToken, 
  saveAuthUser, 
  getAuthToken, 
  getAuthUser, 
  clearAuthData,
  mobileAuthRequest 
} from "@/lib/mobileAuth";

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: any;
  logoutMutation: any;
  registerMutation: any;
};

type LoginData = {
  username: string;
  password: string;
};

type RegisterData = {
  username: string;
  password: string;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();

  // Estado local para usuário mobile (caso não esteja autenticado via sessão)
  const [mobileUser, setMobileUser] = useState<User | null>(() => {
    // Inicializar com dados do localStorage (apenas mobile)
    if (typeof window !== 'undefined' && isMobileDevice()) {
      return getAuthUser();
    }
    return null;
  });

  // Verificar se há token no localStorage ao iniciar
  useEffect(() => {
    if (isMobileDevice()) {
      const savedUser = getAuthUser();
      const token = getAuthToken();
      
      if (savedUser && token) {
        console.log("📱 Dados do usuário encontrados no localStorage:", savedUser.username);
        setMobileUser(savedUser);
        
        // Verificar se o token ainda é válido fazendo uma requisição
        mobileAuthRequest("GET", "/api/me")
          .then(userData => {
            if (userData) {
              console.log("📱 Token validado com sucesso para usuário:", userData.username);
              setMobileUser(userData);
            }
          })
          .catch(err => {
            console.error("📱 Erro ao validar token:", err);
            // Se o token for inválido, limpar dados
            clearAuthData();
            setMobileUser(null);
          });
      }
    }
  }, []);

  const { data: sessionUser, isLoading, error } = useQuery({
    queryKey: ["/api/me"],
    queryFn: async () => {
      try {
        console.log("Buscando dados do usuário...");
        
        // Para dispositivos móveis, usar mobileAuthRequest
        if (isMobileDevice()) {
          const userData = await mobileAuthRequest("GET", "/api/me");
          console.log("📱 Dados do usuário mobile obtidos:", userData);
          
          // Salvar usuário no localStorage
          if (userData) {
            saveAuthUser(userData);
          }
          
          return userData;
        } 
        // Para desktop, usar apiRequest normal
        else {
          const userData = await apiRequest("GET", "/api/me");
          console.log("Dados do usuário obtidos:", userData);
          return userData;
        }
      } catch (error) {
        console.error("Erro ao buscar dados do usuário:", error);
        if (error instanceof Error && error.message.includes("401")) {
          console.log("Usuário não autenticado (401)");
          return null;
        }
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    // Desabilitar a query inicial se já temos um usuário mobile
    enabled: !isMobileDevice() || !mobileUser
  });
  
  // Combinar usuário da sessão com usuário mobile
  const user = sessionUser || mobileUser;

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      let userData;
      
      // Para dispositivos móveis, usar mobileAuthRequest
      if (isMobileDevice()) {
        userData = await mobileAuthRequest("POST", "/api/login", credentials);
        
        // Salvar token se estiver presente
        if (userData && userData.mobile_token) {
          console.log("📱 Token mobile recebido no login");
          saveAuthToken(userData.mobile_token);
          saveAuthUser(userData);
          setMobileUser(userData);
          
          // Remover o token do objeto antes de armazenar no cache
          const { mobile_token, ...userWithoutToken } = userData;
          userData = userWithoutToken;
        }
      } 
      // Para desktop, usar apiRequest normal
      else {
        userData = await apiRequest("POST", "/api/login", credentials);
      }
      
      return userData;
    },
    onSuccess: (userData: User) => {
      queryClient.setQueryData(["/api/me"], userData);
      toast({
        title: "Login realizado com sucesso",
        description: `Bem-vindo(a) de volta, ${userData.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Falha no login",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      // Para dispositivos móveis, limpar dados locais
      if (isMobileDevice()) {
        clearAuthData();
        setMobileUser(null);
        
        // Tentar fazer logout no servidor, mas não falhar se não conseguir
        try {
          await mobileAuthRequest("POST", "/api/logout");
        } catch (error) {
          console.log("📱 Erro ao fazer logout no servidor, mas dados locais foram limpos");
        }
      } 
      // Para desktop, usar apiRequest normal
      else {
        await apiRequest("POST", "/api/logout");
      }
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/me"], null);
      // Redireciona para a página de landing após fazer logout
      window.location.href = '/landing/';
      toast({
        title: "Logout realizado com sucesso",
        description: "Você foi desconectado da sua conta.",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterData) => {
      let response;
      
      // Para dispositivos móveis, usar mobileAuthRequest
      if (isMobileDevice()) {
        response = await mobileAuthRequest("POST", "/api/register", userData);
        
        // Salvar token se estiver presente
        if (response && response.mobile_token) {
          console.log("📱 Token mobile recebido no registro");
          saveAuthToken(response.mobile_token);
          saveAuthUser(response);
          setMobileUser(response);
          
          // Remover o token do objeto antes de armazenar no cache
          const { mobile_token, ...userWithoutToken } = response;
          response = userWithoutToken;
        }
      } 
      // Para desktop, usar apiRequest normal
      else {
        response = await apiRequest("POST", "/api/register", userData);
      }
      
      return response;
    },
    onSuccess: (userData: User) => {
      queryClient.setQueryData(["/api/me"], userData);
      toast({
        title: "Registro realizado com sucesso",
        description: "Sua conta foi criada e você já está logado!",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider");
  }
  return context;
}
