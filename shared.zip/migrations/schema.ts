import { pgTable, foreignKey, serial, integer, text, jsonb, varchar, boolean, unique, uuid, index, json, timestamp } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const analysisResults = pgTable("analysis_results", {
	id: serial().primaryKey().notNull(),
	analysisRequestId: integer("analysis_request_id"),
	personalityPattern: text("personality_pattern").notNull(),
	analysisReport: text("analysis_report").notNull(),
	strategicGuide: text("strategic_guide").notNull(),
	personalizedTips: jsonb("personalized_tips").notNull(),
	completedAt: text("completed_at").notNull(),
	diagnosticoEmocional: text("diagnostico_emocional").notNull(),
	explicacaoBloqueio: text("explicacao_bloqueio").notNull(),
	caminhoLiberacao: text("caminho_liberacao").notNull(),
	traco1Nome: text("traco1_nome").notNull(),
	traco1Percentual: integer("traco1_percentual").notNull(),
	traco1Dor: jsonb("traco1_dor").notNull(),
	traco1Recurso: jsonb("traco1_recurso").notNull(),
	traco2Nome: text("traco2_nome").notNull(),
	traco2Percentual: integer("traco2_percentual").notNull(),
	traco2Dor: jsonb("traco2_dor").notNull(),
	traco2Recurso: jsonb("traco2_recurso").notNull(),
	traco3Nome: text("traco3_nome").notNull(),
	traco3Percentual: integer("traco3_percentual").notNull(),
	traco3Dor: jsonb("traco3_dor").notNull(),
	traco3Recurso: jsonb("traco3_recurso").notNull(),
	acaoTraco1: text("acao_traco1"),
	acaoTraco2: text("acao_traco2"),
	acaoTraco3: text("acao_traco3"),
	updatedAt: text("updated_at").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.analysisRequestId],
			foreignColumns: [analysisRequests.id],
			name: "analysis_results_analysis_request_id_analysis_requests_id_fk"
		}),
]);

export const emotionalPatterns = pgTable("emotional_patterns", {
	id: serial().primaryKey().notNull(),
	patternType: varchar("pattern_type", { length: 30 }).notNull(),
	areaType: varchar("area_type", { length: 30 }).notNull(),
	isPain: boolean("is_pain").notNull(),
	description: text().notNull(),
	createdAt: text("created_at").notNull(),
	updatedAt: text("updated_at").notNull(),
});

export const users = pgTable("users", {
	id: serial().primaryKey().notNull(),
	username: text().notNull(),
	password: text().notNull(),
}, (table) => [
	unique("users_username_unique").on(table.username),
]);

export const bodyScoringTable = pgTable("body_scoring_table", {
	id: serial().primaryKey().notNull(),
	analysisRequestId: integer("analysis_request_id").notNull(),
	criativoHead: integer("criativo_head").default(0).notNull(),
	criativoChest: integer("criativo_chest").default(0).notNull(),
	criativoShoulder: integer("criativo_shoulder").default(0).notNull(),
	criativoBack: integer("criativo_back").default(0).notNull(),
	criativoLegs: integer("criativo_legs").default(0).notNull(),
	conectivoHead: integer("conectivo_head").default(0).notNull(),
	conectivoChest: integer("conectivo_chest").default(0).notNull(),
	conectivoShoulder: integer("conectivo_shoulder").default(0).notNull(),
	conectivoBack: integer("conectivo_back").default(0).notNull(),
	conectivoLegs: integer("conectivo_legs").default(0).notNull(),
	forteHead: integer("forte_head").default(0).notNull(),
	forteChest: integer("forte_chest").default(0).notNull(),
	forteShoulder: integer("forte_shoulder").default(0).notNull(),
	forteBack: integer("forte_back").default(0).notNull(),
	forteLegs: integer("forte_legs").default(0).notNull(),
	liderHead: integer("lider_head").default(0).notNull(),
	liderChest: integer("lider_chest").default(0).notNull(),
	liderShoulder: integer("lider_shoulder").default(0).notNull(),
	liderBack: integer("lider_back").default(0).notNull(),
	liderLegs: integer("lider_legs").default(0).notNull(),
	competitivoHead: integer("competitivo_head").default(0).notNull(),
	competitivoChest: integer("competitivo_chest").default(0).notNull(),
	competitivoShoulder: integer("competitivo_shoulder").default(0).notNull(),
	competitivoBack: integer("competitivo_back").default(0).notNull(),
	competitivoLegs: integer("competitivo_legs").default(0).notNull(),
	criativoTotal: integer("criativo_total").default(0).notNull(),
	conectivoTotal: integer("conectivo_total").default(0).notNull(),
	forteTotal: integer("forte_total").default(0).notNull(),
	liderTotal: integer("lider_total").default(0).notNull(),
	competitivoTotal: integer("competitivo_total").default(0).notNull(),
	criativoPercentage: integer("criativo_percentage").default(0).notNull(),
	conectivoPercentage: integer("conectivo_percentage").default(0).notNull(),
	fortePercentage: integer("forte_percentage").default(0).notNull(),
	liderPercentage: integer("lider_percentage").default(0).notNull(),
	competitivoPercentage: integer("competitivo_percentage").default(0).notNull(),
	primaryPattern: text("primary_pattern").default(').notNull(),
	secondaryPattern: text("secondary_pattern").default(').notNull(),
	tertiaryPattern: text("tertiary_pattern").default(').notNull(),
	scoredBy: text("scored_by").default('analista').notNull(),
	scoringNotes: text("scoring_notes"),
	createdAt: text("created_at").notNull(),
	updatedAt: text("updated_at").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.analysisRequestId],
			foreignColumns: [analysisRequests.id],
			name: "body_scoring_table_analysis_request_id_analysis_requests_id_fk"
		}),
	unique("body_scoring_table_analysis_request_id_unique").on(table.analysisRequestId),
]);

export const photoUploads = pgTable("photo_uploads", {
	id: serial().primaryKey().notNull(),
	analysisRequestId: integer("analysis_request_id"),
	photoType: text("photo_type").notNull(),
	photoPath: text("photo_path").notNull(),
	createdAt: text("created_at").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.analysisRequestId],
			foreignColumns: [analysisRequests.id],
			name: "photo_uploads_analysis_request_id_analysis_requests_id_fk"
		}),
]);

export const analysisRequests = pgTable("analysis_requests", {
	id: serial().primaryKey().notNull(),
	userId: integer("user_id"),
	requestId: uuid("request_id").defaultRandom().notNull(),
	analysisFor: text("analysis_for").notNull(),
	otherReason: text("other_reason"),
	hadSurgery: boolean("had_surgery").notNull(),
	surgeryDetails: text("surgery_details"),
	hadTrauma: boolean("had_trauma").notNull(),
	traumaDetails: text("trauma_details"),
	usedDevice: boolean("used_device").notNull(),
	deviceDetails: text("device_details"),
	priorityArea: text("priority_area").notNull(),
	complaint1: text("complaint_1").notNull(),
	complaint2: text("complaint_2"),
	complaint3: text("complaint_3"),
	frontBodyPhoto: text("front_body_photo").notNull(),
	backBodyPhoto: text("back_body_photo").notNull(),
	seriousFacePhoto: text("serious_face_photo").notNull(),
	smilingFacePhoto: text("smiling_face_photo").notNull(),
	status: text().default('pending').notNull(),
	paymentIntentId: text("payment_intent_id"),
	amount: integer().default(9700).notNull(),
	createdAt: text("created_at").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "analysis_requests_user_id_users_id_fk"
		}),
	unique("analysis_requests_request_id_unique").on(table.requestId),
]);

export const session = pgTable("session", {
	sid: varchar().primaryKey().notNull(),
	sess: json().notNull(),
	expire: timestamp({ precision: 6, mode: 'string' }).notNull(),
}, (table) => [
	index("IDX_session_expire").using("btree", table.expire.asc().nullsLast().op("timestamp_ops")),
]);
